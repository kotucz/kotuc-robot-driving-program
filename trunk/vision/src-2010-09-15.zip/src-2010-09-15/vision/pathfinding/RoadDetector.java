package vision.pathfinding;

/**
 *
 * @author Kotuc
 */
public class RoadDetector {

    private RoadDetector() {
    }

    public static void detect(HeatMap hm) {
//        hm.isRoad(x, y);
    }

}
