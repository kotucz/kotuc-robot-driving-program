package vision;

/**
 *
 * @author kotuc
 */
public interface Shutdownable {
    void shutdown();
}
