package vision.objects;

/**
 *
 * @author Kotuc
 */
public class BorderDetector {
}
