package vision.input;

import java.awt.image.BufferedImage;

/**
 *
 * @author Kotuc
 */
public interface VideoInput {

    BufferedImage snap();
}
