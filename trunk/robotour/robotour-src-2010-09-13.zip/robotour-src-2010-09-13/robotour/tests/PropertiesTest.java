package robotour.tests;
import robotour.util.Setup;
/*
 * SysPropertiesTest.java
 *
 * Created on 28. srpen 2007, 13:26
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author PC
 */
class PropertiesTest {
    
    /** Creates a new instance of SysPropertiesTest */
    public PropertiesTest() {
    }
    
    public static void main(String[] args) {
        Setup.reload();
    }
    
}
