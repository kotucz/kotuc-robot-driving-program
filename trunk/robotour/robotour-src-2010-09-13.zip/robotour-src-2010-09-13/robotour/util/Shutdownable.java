package robotour.util;

/**
 *
 * @author kotuc
 */
public interface Shutdownable {
    void shutdown();
}
