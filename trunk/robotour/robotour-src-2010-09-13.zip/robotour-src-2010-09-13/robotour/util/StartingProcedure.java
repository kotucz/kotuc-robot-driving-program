package robotour.util;

/**
 *
 * @author Kotuc
 */
public class StartingProcedure {

}
