package robotour.util.log.events;

/**
 *
 * @author Kotuc
 */
public class EventPlayer {

}
