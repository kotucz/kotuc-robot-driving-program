package robotour.util;

import java.awt.Graphics;
import robotour.iface.Compass;

/**
 *
 * @author Kotuc
 */
public class CompassHUD {

    private final Compass cmps;

    public CompassHUD(Compass cmps) {
        this.cmps = cmps;
    }

    public void paint(Graphics g) {
    }
}
