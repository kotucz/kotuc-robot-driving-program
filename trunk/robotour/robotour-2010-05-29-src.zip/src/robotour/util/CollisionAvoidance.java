package robotour.util;

import gnu.io.NoSuchPortException;
import gnu.io.PortInUseException;
import gnu.io.UnsupportedCommOperationException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.realtime.AbsoluteTime;
import javax.realtime.Clock;
import robotour.hardware.SSC32;
import robotour.iface.Servo;
import robotour.rt.RealTime;
import robotour.rt.TimeMeassure;

/**
 *
 * @author Kotuc
 */
public class CollisionAvoidance implements Runnable {

    final SSC32 ssc;

    public CollisionAvoidance(SSC32 ssc) {

        this.ssc = ssc;

    }

    public void run() {

        Servo servo = ssc.getServo(31);

        TimeMeassure time = TimeMeassure.getTimeMeassure();

        while (true) {
            try {
                time.reset();
                boolean val;
                val = ssc.readDigitalInput(SSC32.InputPin.A);
                servo.setPosition((val) ? 1 : 0);
                val = ssc.readDigitalInput(SSC32.InputPin.B);
                servo.setPosition((val) ? 1 : 0);
                val = ssc.readDigitalInput(SSC32.InputPin.C);
                servo.setPosition((val) ? 1 : 0);
                val = ssc.readDigitalInput(SSC32.InputPin.D);
                servo.setPosition((val) ? 1 : 0);
                System.out.println("4 read and write: " + time.getTime());
            } catch (IOException ex) {
                Logger.getLogger(CollisionAvoidance.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    public static void main(String[] args) throws PortInUseException, IOException, UnsupportedCommOperationException, NoSuchPortException {
        System.out.println("start");
        RealTime.newThread(new CollisionAvoidance(SSC32.getSSC32(args[0])), 21).start();
        System.out.println("DOnE");
    }
}
