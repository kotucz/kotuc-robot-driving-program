package robotour.hardware;

/**
 *
 * @author Kotuc
 * @deprecated 
 */
public class DeviceManager {
//
//    private static GPSInput gps;
//    private static GamePad gamepad;
//    private static SSC32 ssc32;
//    private static I2CUSB i2c;
//
//    public static I2CUSB getI2C() {
//        if (null == i2c) {
//            try {
//                i2c = I2CUSB.getI2C("/dev/ttyUSB0"); // linux
////                i2c = I2CUSB.getI2C("COM7"); // windows
//            } catch (UnsupportedCommOperationException ex) {
//                Logger.getLogger(DeviceManager.class.getName()).log(Level.SEVERE, null, ex);
//            } catch (IOException ex) {
//                Logger.getLogger(DeviceManager.class.getName()).log(Level.SEVERE, null, ex);
//            } catch (PortInUseException ex) {
//                Logger.getLogger(DeviceManager.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        }
//        return i2c;
//    }
//
//    public static GamePad getGamepad() {
//        if (null == gamepad) {
//            gamepad = GamePad.getActiveGamePad();
//        }
//        return gamepad;
//    }
//
//    public static SSC32 getSsc32() {
//        if (null == ssc32) {
//            try {
//                ssc32 = SSC32.getSSC32("/dev/ttyS0");
//            } catch (UnsupportedCommOperationException ex) {
//                Logger.getLogger(DeviceManager.class.getName()).log(Level.SEVERE, null, ex);
//            } catch (PortInUseException ex) {
//                Logger.getLogger(DeviceManager.class.getName()).log(Level.SEVERE, null, ex);
//            } catch (IOException ex) {
//                Logger.getLogger(DeviceManager.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        }
//        return ssc32;
//    }
//
//    public static GPSInput getGps() {
//        if (null == gps) {
//            try {
//                gps = GPSInput.openGPSInput("COM3");
//            } catch (IllegalArgumentException ex) {
//                Logger.getLogger(DeviceManager.class.getName()).log(Level.SEVERE, null, ex);
//            } catch (IOException ex) {
//                Logger.getLogger(DeviceManager.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        }
//        return gps;
//    }
}
