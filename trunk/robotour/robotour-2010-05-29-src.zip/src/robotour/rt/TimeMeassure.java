package robotour.rt;

import javax.realtime.AbsoluteTime;
import javax.realtime.Clock;

/**
 *
 * @author Kotuc
 */
public class TimeMeassure {

    private Clock clock = Clock.getRealtimeClock();
    private AbsoluteTime startTime;

    public static TimeMeassure getTimeMeassure() {
        return new TimeMeassure();
    }

    private  TimeMeassure() {
        reset();
    }

    public void reset() {
        startTime = clock.getTime();
    }

    public Object getTime() {
        return clock.getTime().subtract(startTime);
    }

}
