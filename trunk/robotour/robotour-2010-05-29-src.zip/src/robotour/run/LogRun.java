package robotour.run;

import robotour.util.RobotSystems;

/**
 *
 * @author Kotuc
 */
public class LogRun {



    public LogRun(RobotSystems systems) {
//        systems.get
    }



}
