package robotour.run;

import java.awt.image.BufferedImage;
import java.util.logging.Level;
import java.util.logging.Logger;
import robotour.iface.Wheels;
import robotour.util.RobotSystems;
import vision.ImageFrame;
import vision.input.VideoInput;
import vision.pathfinding.PathRecog;

/**
 *
 * @author Kotuc
 */
public class MainCam {

    private VideoInput video;
    private Wheels wheels;
    private ImageFrame imgFrame;

    public MainCam(RobotSystems systems) {
        this.video = systems.getVideo();
        this.wheels = systems.getWheels();
        this.imgFrame = new ImageFrame("PathRecog");
        imgFrame.setVisible(true);
    }

    public static void main(String[] args) {
        new MainCam(RobotSystems.getLocalHard()).run();
    }

    public void run() {
        wheels.stop();
        while (true) {
            act();
            try {
                Thread.sleep(50);
            } catch (InterruptedException ex) {
                Logger.getLogger(MainCam.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    private PathRecog precog = new PathRecog();

    public void act() {

        BufferedImage image = video.snap();

        precog.process(image);

        wheels.setSteer(precog.getGoodSteer());

        wheels.setSpeed(0.3); // avare obstacles

        imgFrame.setImage(precog.getResult());

    }
}
