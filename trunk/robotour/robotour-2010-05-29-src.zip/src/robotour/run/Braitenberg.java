package robotour.run;

import robotour.util.RobotSystems;
import robotour.iface.MeasureException;
import robotour.iface.Wheels;
import robotour.util.Sonars;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import robotour.hardware.SSC32.InputPin;
import robotour.hardware.Switch;

/**
 *
 * @author Kotuc
 */
public class Braitenberg implements Runnable {

//    private final Compass cmps;
    private final Wheels wheels;
    private final Sonars sonars;
//    private final Odometry odometry;
//    private final Switch swit;

    private Braitenberg() throws RemoteException, NotBoundException {
        RobotSystems systems = RobotSystems.getDefault();
//        cmps = systems.getCompass();
        wheels = systems.getWheels();
        sonars = systems.getSonars();
//        swit = systems.getSsc().getSwitch(InputPin.B);

//        odometry = new Odometry(wheels, cmps);
//        odometry.startOdometryThread();
//        LocalMap.showMap(sonars, cmps, odometry);
    }
//    private int targetAzimuth = 90;
    private long runMillis = 0;

    public void run() {
        while (true) {
//            System.out.println("Waiting for release");
 //           swit.waitForRelease();
  //          while (swit.isReleased()) {
                act();
 //           }
 //           wheels.stop();
//            swit.waitForRelease();
        }

    }

    public void runEurobot() {
        for (int i = 10; i > 0; i--) {
            try {
                System.out.println("" + i + " seconds to start");
                wheels.stop();
                Thread.sleep(1000); // 30 s to start
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
        System.out.println("" + 0 + " seconds. Starting now!");
        long startt = System.currentTimeMillis(); // 90 s to end
        while ((runMillis = (System.currentTimeMillis() - startt)) < 90 * 1000) {
            act();
        }
        wheels.stop();

        System.exit(0);
    }

    protected long runTime() {
        return runMillis;
    }

    public void act() {

//        while (true) {
//          sonars.poll();    // using separate thread

        double speed = 0;

        try {
            double dist = sonars.getCenter().getDistance();
            if (dist < 5.0) {
                speed = Math.max(-1, (Math.min((dist - 0.10), 1.0)));
            }
        } catch (MeasureException ex) {
            Logger.getLogger(Braitenberg.class.getName()).log(Level.SEVERE, null, ex);
        }

//            wheels.setSpeed(0);
        wheels.setSpeed(speed);


        double steer = 0;
        try {
            steer = Math.max(0, 1 - sonars.getLeft().getDistance()) - Math.max(0, 1 - sonars.getRight().getDistance());

//        steer += Math.signum(steer)*Math.max(0, 1-dist); // proxiity boost // digital behavior left/right
            steer = Math.signum(steer) * Math.max(0, 1 - speed); // fill the rest of speed with turnign
        } catch (MeasureException ex) {
            Logger.getLogger(Braitenberg.class.getName()).log(Level.SEVERE, null, ex);
        }

        wheels.setSteer(Math.max(-1, Math.min(steer, 1)));


        System.out.println(runTime() + "; " + sonars + "; speed: " + speed + " steer: " + steer);
        try {
            Thread.sleep(15);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }


    }

    public static void main(String[] args) throws RemoteException, NotBoundException {
//        Wheels.getFakeWheels().setSpeed(0);
        new Thread(new Braitenberg()).start();
    }
}
