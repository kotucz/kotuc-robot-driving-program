/*
 * MapLayer.java
 *
 * Created on 27. srpen 2007, 16:03
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package robotour.gui.map;

/**
 *
 * @author Kotuc
 */
public interface MapLayer {
    public void paint(MapView map);
}
