package robotour.tests;
import robotour.navi.gps.GPSPoint;
/*
 * GPSPointTest.java
 *
 * Created on 29. srpen 2007, 16:24
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author PC
 */
class GPSPointTest {
    
    /** Creates a new instance of GPSPointTest */
    private GPSPointTest() {
    }
    
    public static void main(String[] args) {
//        GPSPoint g0 = new GPSPoint();
//        GPSPoint gne = new GPSPoint(1, 4);
//        GPSPoint gne2 = new GPSPoint(2, 4);
//        GPSPoint gse = new GPSPoint(-1, 4);
//        GPSPoint gsw = new GPSPoint(-1, -4);
//        GPSPoint gnw = new GPSPoint(1, -4);
//
//        new GPSPoint(10, 10).getAzimuthTo(new GPSPoint(20, 10));
//        g0.getAzimuthTo(gne);
//        g0.getAzimuthTo(gse);
//        new GPSPoint(10, 10).getAzimuthTo(new GPSPoint(10, 20));
//        g0.getAzimuthTo(gsw);
//        g0.getAzimuthTo(gnw);
//        gne.getAzimuthTo(gne2);
//        gne2.getAzimuthTo(gne);

        System.err.println("NOT ALL DONE!");
//        g0.("12.34.56,67");
//        g0.setLong("12.34.56,67");
//        g0.setLat("12o34\"56,67");
//        g0.setLong("12o34\"56,67");
        
    }
    
}
