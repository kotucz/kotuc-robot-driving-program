package robotour.navi.gps;

import gnu.io.NoSuchPortException;
import java.io.IOException;
import javax.swing.JFrame;

/**
 *
 * @author Kotuc
 */
public class GPSTest {

    /**
     * @param args
     */
    public static void main(String[] args) throws IllegalArgumentException, IOException, NoSuchPortException {

        System.err.println("Usage: java GPSInput <gpsport>");

//        GPSInput gpsi = GPSInput.opportenGPSInput(args[0]);
        GPSInput gpsi = GPSInput.openPort("COM6");
//        GPSInput gpsi = GPSInput.openFile(new File("COM7"));

        JFrame frame = new JFrame("GPS Input Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new GPSPanel(gpsi));
        frame.pack();
        frame.setVisible(true);

    }
}
