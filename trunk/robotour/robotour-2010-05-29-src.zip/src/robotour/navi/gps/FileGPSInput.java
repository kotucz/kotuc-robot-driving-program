package robotour.navi.gps;

import java.awt.Color;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Kotuc
 */
class FileGPSInput extends GPSInput implements Runnable {

    private final GPSInput gps = this;
    private final BufferedReader reader;

    FileGPSInput(File file) throws IOException {
        reader = new BufferedReader(new FileReader(file));

        new Thread(this).start();
    }

    public void run() {
//        Thread.currentThread().setDaemon(true);
        while (true) {
            try {
                gps.parseNMEA(reader.readLine());

                Thread.sleep(10);
            } catch (InterruptedException ex) {
                Logger.getLogger(FileGPSInput.class.getName()).log(Level.SEVERE, null, ex);

            } catch (IOException ex) {
                Logger.getLogger(FileGPSInput.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
