/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package robotour.iface;

/**
 *
 * @author kotuc
 */
public interface Encoder {

    /**
     *
     * @return
     */
    double getSpeed();

}
