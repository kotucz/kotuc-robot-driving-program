package robotour.iface;

/**
 *
 * @author kotuc
 */
public interface Sonar {
    double getDistance() throws MeasureException;
}
