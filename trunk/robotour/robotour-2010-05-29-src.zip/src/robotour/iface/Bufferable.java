package robotour.iface;

/**
 *
 * @author Tomas
 */
public interface Bufferable {

    void readToBuffer();
}
