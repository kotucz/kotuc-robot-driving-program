package robotour.behavior;

/**
 *
 * @author Kotuc
 */
public interface Condition {
    boolean applies();
}
