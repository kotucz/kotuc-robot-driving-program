package robotour.util.log.events;

/**
 *
 * @author Kotuc
 */
public interface EventListener {

    public void eventRecieved(Event event);
}
