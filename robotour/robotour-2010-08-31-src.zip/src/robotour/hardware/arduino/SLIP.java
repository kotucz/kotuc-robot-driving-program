package robotour.hardware.arduino;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import robotour.iface.MeasureException;
import robotour.util.Binary;

/**
 *
 * @author Kotuc
 * @see http://www.tcpipguide.com/free/t_SerialLineInternetProtocolSLIP-2.htm
 */
public class SLIP {

    protected static final byte SLIP_END = (byte) 0xC0;
    protected static final byte SLIP_ESC = (byte) 0xDB;
    protected static final byte SLIP_ESC_END = (byte) 0xDC;
    protected static final byte SLIP_ESC_ESC = (byte) 0xDD;
    private final ArduinoSerial serial;
    private final ArduinoRobot robot;
    final SLIPOutputStream slipos;
    final DataOutputStream sliposdata;
    final SLIPInput input;

    public SLIP(ArduinoSerial serial, ArduinoRobot robot) {
        this.slipos = new SLIPOutputStream(serial.getOutputStream());
        this.sliposdata = new DataOutputStream(slipos);
        this.input = new SLIPInput();
        this.serial = serial;

        this.robot = robot;
        listen();
    }

    void listen() {
        new Thread(input).start();
    }

    void received(List<Byte> buffer) {
        try {
            byte[] bytes = Binary.toArray(buffer);
            DataInputStream dis = new DataInputStream(new ByteArrayInputStream(bytes));

            //        int time = toInt32(bytes, 0);
            int time = dis.readInt();

            byte type = dis.readByte();

//            short val = toInt16(bytes, 5);
            short val = dis.readShort();

            switch (type) {
                case 'a':
//                    System.out.println("azimuth*10: " + val);
                    robot.compass.measuredDegTen(val);
                    try {
                        robot.odometry.updatedAzimuth(robot.compass.getAzimuth());
                    } catch (MeasureException ex) {
                        Logger.getLogger(SLIP.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    break;
                case 'l':
                    System.out.println("left cm: " + val);
                    robot.leftSrf.measuredCM(val);
                    break;
                case 'c':
                    System.out.println("center cm: " + val);
                    robot.centerSrf.measuredCM(val);
                    break;
                case 'r':
                    System.out.println("right cm: " + val);
                    robot.rightSrf.measuredCM(val);
                    break;
                case 'e':
                    System.out.println("encoder ticks: " + val);
                    robot.odometer.setTicks(val);
                    robot.odometry.updatedOdometer(robot.odometer.getChange());
                    break;
                default:
                    System.err.println("unknown event: \"" + new String(bytes)+"\" "+Arrays.toString(bytes));
            }
            //        System.out.print("Msg:");
            //        for (Byte byte1 : buffer) {
            //            System.out.print(" " + byte1);
            //        }
            //        System.out.println();
        } catch (IOException ex) {
            Logger.getLogger(SLIP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    class SLIPInput implements Runnable {

        private byte chsum = 0;
        private boolean prevEsc = false;
        private List<Byte> buffer = new ArrayList<Byte>();

        void receivedByte(byte b) {
            switch (b) {
                case SLIP_END:
                    prevEsc = false;
                    // verify and perform
                    if (0 == chsum) {
                        if (buffer.size() > 0) {
                            received(buffer);
                        } else {
//                        System.err.println("empty message ");
                        }
                    } else {
                        System.err.println("wrong checksum " + chsum + ": " + new String(Binary.toArray(buffer)));
                    }
                    // reset
                    chsum = 0;
                    buffer.clear();
                    break;
                case SLIP_ESC:
                    // replace next
                    prevEsc = true;
                    break;
                default:
                    if (prevEsc) {
                        prevEsc = false;
                        if (b == SLIP_ESC_END) {
                            b = SLIP_END;
                        } else if (b == SLIP_ESC_ESC) {
                            b = SLIP_ESC;
                        } else {
                            // error
                        }
                    }
                    // count data
                    buffer.add((byte) b);
                    chsum ^= b;
            }
        }

        public void run() {
            while (true) {
                try {
                    receivedByte(serial.readByte());
                } catch (IOException ex) {
                    Logger.getLogger(SLIP.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    void sendMessage(byte[] bytes) throws IOException {
        slipos.sendMessage(bytes);
    }
}
