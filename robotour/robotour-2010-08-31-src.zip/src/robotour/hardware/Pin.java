package robotour.hardware;

/**
 *
 * @author Kotuc
 */
public class Pin {

    boolean state;

    public void set(boolean state) {
        
    }

}
