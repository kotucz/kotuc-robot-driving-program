package robotour.hardware;

import javax.media.bean.playerbean.MediaPlayer;
import javax.swing.JFrame;

/**
 *  Probably not working
 * use SoundPlay
 * @author PC
 */
class Speaker {

    private MediaPlayer player = new MediaPlayer();

    /** Creates a new instance of Speaker */
    public Speaker() {
//        player.setMediaLocation(getClass().getResource("/sounds/odyssey.mp3").toString());
        player.setMediaLocation("sounds/zena.wav");
        player.setPlaybackLoop(false);
        player.start();
    }

    public void say() {
        System.out.println("HELLO MAN!");
    }

    public static void main(String[] args) {
        new Speaker();
        JFrame frame = new JFrame("Speaker test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(200, 100);
        frame.setVisible(true);
    }
}
