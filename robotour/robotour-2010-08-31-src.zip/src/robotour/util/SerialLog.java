package robotour.util;

import robotour.util.log.TeeOutputStream;
import robotour.util.log.TeeInputStream;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import vision.input.VideoInput;

/**
 *
 * @author Kotuc
 */
public class SerialLog {

    static File logDirectory;

    public static File getLogDirectory() {
        if (logDirectory == null) {
//            logDirectory = new File("./logs/run-" + System.currentTimeMillis() + "/");
//            logDirectory = new File("./logs/run-" + createReadableTime() + "/");
            logDirectory = new File(System.getProperty("user.home")+"/RobotourLogs/run-" + createReadableTime() + "/");
            logDirectory.mkdirs();
            logDirectory.mkdir();
        }
        return logDirectory;
    }

    public static String createReadableTime() {
//        new Date().getH;
        final Calendar cal = Calendar.getInstance();
        String time = "" + (long) ((10000L * cal.get(Calendar.YEAR)
                + 100 * (cal.get(Calendar.MONTH) + 1)
                + cal.get(Calendar.DAY_OF_MONTH)) * 1000000
                + +10000 * cal.get(Calendar.HOUR_OF_DAY)
                + +100 * cal.get(Calendar.MINUTE)
                + +cal.get(Calendar.SECOND));
        return time;
    }

    public static File createLogFile(String name) {
//        File file = new File(getLogDirectory(), name + "-" + System.currentTimeMillis() + ".log");
        File file = new File(getLogDirectory(), name + "-" + createReadableTime() + ".log");
        return file;
    }

    public static OutputStream getLoggedOutputStream(OutputStream originalOutput, File logFile) throws FileNotFoundException {
        FileOutputStream fos = new FileOutputStream(logFile);
        TeeOutputStream tos = new TeeOutputStream(originalOutput, fos);
        return tos;
    }

    public static InputStream getLoggedInputStream(InputStream originalInput, File logFile) throws FileNotFoundException {
        FileOutputStream fos = new FileOutputStream(logFile);
        TeeInputStream tis = new TeeInputStream(originalInput, fos);
        return tis;
    }

    public static VideoInput getLoggedVideoInput(final VideoInput vi) {
        File file = new File(logDirectory, "video/");
        file.mkdir();
        return getLoggedVideoInput(vi, file);
    }

    public static VideoInput getLoggedVideoInput(final VideoInput vi, final File viLogDir) {

        return new VideoInput() {
            
            public BufferedImage snap() {
                BufferedImage image = vi.snap();
                try {
                    ImageIO.write(image, "png", new File(viLogDir, "snap" + System.currentTimeMillis() + ".png"));
                } catch (IOException ex) {
                    Logger.getLogger(SerialLog.class.getName()).log(Level.SEVERE, null, ex);
                }
                return image;
            }

        };
        
    }

//    static void chain(InputStream inputStream, OutputStream outputStream) {
//
//    }
}
