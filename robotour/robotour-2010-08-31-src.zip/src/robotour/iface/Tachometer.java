package robotour.iface;

/**
 *
 * @author kotuc
 */
public interface Tachometer {

    /**
     *
     * @return speed in meters/second 
     */
    double getSpeed();

}
